/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import dao.DBconnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author zitas
 */

@WebServlet("/signup")
public class signup extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Ambil data dari form signup
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection connection = DBconnection.getConnection()) {
            // Cek apakah email sudah terdaftar
            String checkEmailSql = "SELECT email FROM customers WHERE email = ?";
            PreparedStatement checkStatement = connection.prepareStatement(checkEmailSql);
            checkStatement.setString(1, email);
            ResultSet resultSet = checkStatement.executeQuery();

            if (resultSet.next()) {
                // Jika email sudah terdaftar, tampilkan pesan
                response.getWriter().println("<h3>Email sudah terdaftar. Silakan <a href='login.jsp'>login</a>.</h3>");
            } else {
                // Jika email belum terdaftar, insert data baru ke database
                String insertSql = "INSERT INTO customers (username, email, password) VALUES (?, ?, ?)";
                PreparedStatement insertStatement = connection.prepareStatement(insertSql);
                insertStatement.setString(1, username);
                insertStatement.setString(2, email);
                insertStatement.setString(3, password);

                int rowsInserted = insertStatement.executeUpdate();

                if (rowsInserted > 0) {
                    // Jika pendaftaran berhasil, simpan username di session dan redirect ke halaman utama
                    HttpSession session = request.getSession();
                    session.setAttribute("user", username);
                    response.sendRedirect("main.jsp"); // Arahkan ke halaman utama
                } else {
                    // Jika terjadi kesalahan saat insert data
                    response.getWriter().println("<h3>Terjadi kesalahan saat pendaftaran. Silakan coba lagi.</h3>");
                }
            }
        } catch (Exception e) {
            // Menangani kesalahan dan menampilkan pesan yang sesuai
            e.printStackTrace();  // Untuk melihat detail kesalahan
            response.getWriter().println("<h3>Terjadi kesalahan! Silakan coba lagi nanti.</h3>");
        }
    }
}
