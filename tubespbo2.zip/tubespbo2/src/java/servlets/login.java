/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import dao.DBconnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/login")
public class login extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Ambil data dari form login
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Koneksi ke database melalui DBconnection
        try (Connection connection = DBconnection.getConnection()) {
            // Query untuk memeriksa apakah email ada di database
            String checkEmailSql = "SELECT * FROM customers WHERE email = ?";
            PreparedStatement checkEmailStatement = connection.prepareStatement(checkEmailSql);
            checkEmailStatement.setString(1, email);
            ResultSet emailResultSet = checkEmailStatement.executeQuery();

            if (emailResultSet.next()) {
                // Email ditemukan, cek password
                String storedPassword = emailResultSet.getString("password");

                if (storedPassword.equals(password)) {
                    // Password benar, login berhasil
                    HttpSession session = request.getSession();
                    session.setAttribute("user", emailResultSet.getString("username")); // Simpan username di session
                    response.sendRedirect("main.jsp"); // Arahkan ke halaman utama
                } else {
                    // Password salah
                    response.getWriter().println("<h3>Password salah. Silakan coba lagi.</h3>");
                }
            } else {
                // Email belum terdaftar
                response.getWriter().println("<h3>Email belum terdaftar. Silakan <a href='signup.jsp'>sign up</a>.</h3>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h3>Terjadi kesalahan. Silakan coba lagi nanti.</h3>");
        }
    }
}